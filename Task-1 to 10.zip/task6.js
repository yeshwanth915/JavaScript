
let a=5; 
let b=7; 

function arithmeic(a,b){
    let sum = a+b;
    let sub =a-b;
    let mul = a*b;
    let div =a/b;
    return sum,sub,mul,div;
}
document.write("sum: "+arithmeic(a,b),"sub :"+arithmeic(a,b),"mul :"+arithmeic(a,b),"div: "+arithmeic(a,b));

